from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional, Tuple
import math

from app.models.user import User
from app.models.portfolio import PortfolioItem
from app.models.transaction import Transaction, TradeType
from app.schemas.trading import TradeRequest, TradeResponse, PortfolioSummary, PortfolioItemOut
from app.services.stock_service import get_stock_price, get_stock_quote, MOCK_STOCKS


async def execute_trade(
    db: AsyncSession,
    user: User,
    trade_request: TradeRequest,
) -> TradeResponse:
    """
    Execute a buy or sell trade with full transactional safety.
    
    Buy logic:
    - Validate sufficient wallet balance
    - Fetch live price
    - Deduct from wallet
    - Update or create portfolio item
    - Recalculate weighted average price
    
    Sell logic:
    - Validate sufficient holdings
    - Fetch live price
    - Credit wallet
    - Update portfolio item
    - Calculate realized P&L
    """
    symbol = trade_request.symbol.upper()
    quantity = trade_request.quantity
    trade_type = trade_request.trade_type

    # Fetch live price
    live_price = await get_stock_price(symbol)
    if live_price is None:
        return TradeResponse(
            success=False,
            message=f"Symbol '{symbol}' not found or price unavailable",
            symbol=symbol,
            trade_type=trade_type.value,
            quantity=quantity,
            price=0,
            total_value=0,
            wallet_balance=user.wallet_balance,
        )

    total_value = round(quantity * live_price, 2)

    # Get stock info
    stock_info = MOCK_STOCKS.get(symbol, {})
    company_name = stock_info.get("name", symbol)
    sector = stock_info.get("sector", "Unknown")

    # Fetch current portfolio item
    result = await db.execute(
        select(PortfolioItem).where(
            and_(PortfolioItem.user_id == user.id, PortfolioItem.symbol == symbol)
        )
    )
    portfolio_item = result.scalar_one_or_none()

    realized_pnl = 0.0
    avg_price_at_trade = portfolio_item.average_price if portfolio_item else live_price

    if trade_type == TradeType.BUY:
        # Validate balance
        if user.wallet_balance < total_value:
            return TradeResponse(
                success=False,
                message=f"Insufficient balance. Required: ₹{total_value:,.2f}, Available: ₹{user.wallet_balance:,.2f}",
                symbol=symbol,
                trade_type=trade_type.value,
                quantity=quantity,
                price=live_price,
                total_value=total_value,
                wallet_balance=user.wallet_balance,
            )

        # Deduct from wallet
        user.wallet_balance = round(user.wallet_balance - total_value, 2)

        if portfolio_item:
            # Recalculate weighted average price
            old_total_value = portfolio_item.quantity * portfolio_item.average_price
            new_total_value = old_total_value + total_value
            new_quantity = portfolio_item.quantity + quantity
            portfolio_item.average_price = round(new_total_value / new_quantity, 4)
            portfolio_item.quantity = round(new_quantity, 4)
        else:
            # Create new portfolio item
            portfolio_item = PortfolioItem(
                user_id=user.id,
                symbol=symbol,
                company_name=company_name,
                quantity=quantity,
                average_price=live_price,
                sector=sector,
            )
            db.add(portfolio_item)

    elif trade_type == TradeType.SELL:
        # Validate holdings
        if not portfolio_item or portfolio_item.quantity < quantity:
            owned = portfolio_item.quantity if portfolio_item else 0
            return TradeResponse(
                success=False,
                message=f"Insufficient holdings. Attempting to sell {quantity}, owned: {owned}",
                symbol=symbol,
                trade_type=trade_type.value,
                quantity=quantity,
                price=live_price,
                total_value=total_value,
                wallet_balance=user.wallet_balance,
            )

        avg_price_at_trade = portfolio_item.average_price

        # Calculate realized P&L
        realized_pnl = round((live_price - portfolio_item.average_price) * quantity, 2)

        # Credit wallet
        user.wallet_balance = round(user.wallet_balance + total_value, 2)

        # Update holdings
        portfolio_item.quantity = round(portfolio_item.quantity - quantity, 4)

        # Remove if quantity is effectively zero
        if portfolio_item.quantity < 0.0001:
            await db.delete(portfolio_item)
            portfolio_item = None

    # Record transaction
    transaction = Transaction(
        user_id=user.id,
        symbol=symbol,
        company_name=company_name,
        trade_type=trade_type,
        quantity=quantity,
        price=live_price,
        total_value=total_value,
        wallet_balance_after=user.wallet_balance,
        realized_pnl=realized_pnl if trade_type == TradeType.SELL else None,
        avg_price_at_trade=avg_price_at_trade,
    )
    db.add(transaction)

    await db.flush()
    await db.refresh(transaction)

    action = "Bought" if trade_type == TradeType.BUY else "Sold"
    pnl_msg = f" | P&L: ₹{realized_pnl:+,.2f}" if trade_type == TradeType.SELL else ""

    return TradeResponse(
        success=True,
        message=f"{action} {quantity} shares of {symbol} @ ₹{live_price:,.2f}{pnl_msg}",
        transaction_id=transaction.id,
        symbol=symbol,
        trade_type=trade_type.value,
        quantity=quantity,
        price=live_price,
        total_value=total_value,
        wallet_balance=user.wallet_balance,
        realized_pnl=realized_pnl if trade_type == TradeType.SELL else None,
    )


def calculate_risk_score(holdings: list, total_portfolio_value: float) -> Tuple[float, str]:
    """
    Calculate portfolio risk score (0-100) based on:
    1. Concentration risk: HHI (Herfindahl-Hirschman Index)
    2. Sector diversification
    3. Volatility exposure (number of holdings)
    
    Returns: (score, label)
    """
    if not holdings or total_portfolio_value <= 0:
        return 0.0, "No Holdings"

    # Concentration risk using HHI
    weights = [h["current_value"] / total_portfolio_value for h in holdings if h.get("current_value", 0) > 0]
    hhi = sum(w ** 2 for w in weights)  # 0 = diversified, 1 = concentrated
    concentration_score = hhi * 50  # Scale to 0-50

    # Sector concentration
    sectors = {}
    for h in holdings:
        sector = h.get("sector", "Unknown")
        sectors[sector] = sectors.get(sector, 0) + h.get("current_value", 0)

    sector_weights = [v / total_portfolio_value for v in sectors.values()]
    sector_hhi = sum(w ** 2 for w in sector_weights)
    sector_score = sector_hhi * 30  # Scale to 0-30

    # Number of holdings (fewer = riskier)
    num_holdings = len(holdings)
    if num_holdings >= 10:
        diversity_score = 0
    elif num_holdings >= 5:
        diversity_score = 10
    elif num_holdings >= 3:
        diversity_score = 15
    else:
        diversity_score = 20

    total_score = min(100, concentration_score + sector_score + diversity_score)
    total_score = round(total_score, 1)

    if total_score >= 70:
        label = "High Risk"
    elif total_score >= 40:
        label = "Medium Risk"
    elif total_score >= 20:
        label = "Low-Medium"
    else:
        label = "Low Risk"

    return total_score, label


async def get_portfolio_summary(db: AsyncSession, user: User) -> PortfolioSummary:
    """
    Calculate complete portfolio summary with:
    - Current holdings with live prices
    - Unrealized P&L per stock
    - Total portfolio value
    - Daily performance
    - Risk score
    """
    # Fetch all portfolio items
    result = await db.execute(
        select(PortfolioItem).where(PortfolioItem.user_id == user.id)
    )
    items = result.scalars().all()

    holdings = []
    total_invested = 0.0
    portfolio_value = 0.0

    for item in items:
        quote = await get_stock_quote(item.symbol)
        current_price = quote["price"] if quote else item.average_price

        current_value = round(item.quantity * current_price, 2)
        invested_value = round(item.quantity * item.average_price, 2)
        unrealized_pnl = round(current_value - invested_value, 2)
        pnl_pct = round((unrealized_pnl / invested_value) * 100, 2) if invested_value > 0 else 0

        holdings.append({
            "id": item.id,
            "symbol": item.symbol,
            "company_name": item.company_name or item.symbol,
            "quantity": item.quantity,
            "average_price": item.average_price,
            "current_price": current_price,
            "current_value": current_value,
            "unrealized_pnl": unrealized_pnl,
            "pnl_percentage": pnl_pct,
            "sector": item.sector or "Unknown",
        })

        total_invested += invested_value
        portfolio_value += current_value

    total_value = round(portfolio_value + user.wallet_balance, 2)
    total_pnl = round(total_value - user.starting_balance, 2)
    total_pnl_pct = round((total_pnl / user.starting_balance) * 100, 2) if user.starting_balance > 0 else 0

    # Approximate daily change (simplified: treat unrealized as today's change)
    daily_change = round(portfolio_value - total_invested, 2)
    daily_change_pct = round((daily_change / total_invested) * 100, 2) if total_invested > 0 else 0

    # Risk score
    risk_score, risk_label = calculate_risk_score(holdings, portfolio_value)

    holding_items = [PortfolioItemOut(**h) for h in holdings]

    return PortfolioSummary(
        wallet_balance=round(user.wallet_balance, 2),
        portfolio_value=round(portfolio_value, 2),
        total_invested=round(total_invested, 2),
        total_value=total_value,
        total_pnl=total_pnl,
        total_pnl_percentage=total_pnl_pct,
        daily_change=daily_change,
        daily_change_percentage=daily_change_pct,
        risk_score=risk_score,
        risk_label=risk_label,
        holdings=holding_items,
    )
