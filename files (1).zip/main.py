from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
import logging

from app.core.config import settings
from app.db.database import init_db
from app.api import api_router, ws_router
from app.websockets.manager import price_broadcast_loop

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Background tasks
_background_tasks = []


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events"""
    logger.info("🚀 Actually - Starting up...")

    # Initialize database tables
    await init_db()
    logger.info("✅ Database initialized")

    # Start price broadcast background loop
    task = asyncio.create_task(price_broadcast_loop())
    _background_tasks.append(task)
    logger.info("✅ Price broadcast loop started")

    yield

    # Shutdown
    logger.info("🔻 Shutting down...")
    for task in _background_tasks:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(
    title="Actually - Stock Market Simulation",
    description="Real-time virtual stock trading with live prices and AI news",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(api_router)
app.include_router(ws_router)


@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "Actually API"}


@app.get("/")
async def root():
    return {
        "message": "Welcome to Actually - Real-time Stock Market Simulation",
        "docs": "/docs",
        "health": "/health",
    }
