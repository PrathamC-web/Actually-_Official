import React, { useState, useEffect, useCallback } from 'react'
import { marketAPI, newsAPI, tradingAPI } from '../api'
import { useAuth } from '../context/AuthContext'
import { useMarketWebSocket } from '../hooks/useWebSocket'
import TradeModal from '../components/ui/TradeModal'
import TickerTape from '../components/ui/TickerTape'
import Layout from '../components/layout/Layout'
import {
  formatCurrency, formatPercent, getPnlClass, 
  getSentimentBadge, truncate, timeAgo, isPositive
} from '../utils/format'
import { 
  TrendingUp, TrendingDown, Search, RefreshCw,
  Newspaper, BarChart2, Activity, ArrowUpRight
} from 'lucide-react'

export default function DashboardPage() {
  const { user, updateUser } = useAuth()
  const { prices, connected } = useMarketWebSocket()

  const [stocks, setStocks] = useState([])
  const [news, setNews] = useState([])
  const [portfolio, setPortfolio] = useState(null)
  const [selectedStock, setSelectedStock] = useState(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [loadingStocks, setLoadingStocks] = useState(true)
  const [loadingNews, setLoadingNews] = useState(true)
  const [activeTab, setActiveTab] = useState('stocks') // 'stocks' | 'news'

  // Load initial data
  useEffect(() => {
    loadStocks()
    loadNews()
    loadPortfolio()
  }, [])

  // Merge WebSocket prices into stocks list
  useEffect(() => {
    if (Object.keys(prices).length === 0) return
    setStocks(prev => prev.map(stock => {
      const live = prices[stock.symbol]
      return live ? { ...stock, ...live } : stock
    }))
  }, [prices])

  const loadStocks = async () => {
    try {
      setLoadingStocks(true)
      const res = await marketAPI.getAllStocks()
      setStocks(res.data)
    } catch (e) {
      console.error('Failed to load stocks:', e)
    } finally {
      setLoadingStocks(false)
    }
  }

  const loadNews = async () => {
    try {
      setLoadingNews(true)
      const res = await newsAPI.getNews()
      setNews(res.data)
    } catch (e) {
      console.error('Failed to load news:', e)
    } finally {
      setLoadingNews(false)
    }
  }

  const loadPortfolio = async () => {
    try {
      const res = await tradingAPI.getPortfolio()
      setPortfolio(res.data)
      if (res.data) {
        updateUser({ wallet_balance: res.data.wallet_balance })
      }
    } catch (e) {}
  }

  const handleTradeSuccess = useCallback((tradeResult) => {
    updateUser({ wallet_balance: tradeResult.wallet_balance })
    loadPortfolio()
    setSelectedStock(null)
  }, [updateUser])

  const filteredStocks = stocks.filter(s =>
    s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.company_name?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getHolding = (symbol) => portfolio?.holdings?.find(h => h.symbol === symbol)

  // Summary stats
  const gainers = stocks.filter(s => s.change_percent > 0).sort((a, b) => b.change_percent - a.change_percent).slice(0, 3)
  const losers = stocks.filter(s => s.change_percent < 0).sort((a, b) => a.change_percent - b.change_percent).slice(0, 3)

  return (
    <>
      <TickerTape stocks={stocks} />
      <Layout wsConnected={connected}>
        <div className="space-y-6">
          {/* Header Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="card">
              <p className="stat-label mb-1">Wallet</p>
              <p className="stat-value">{formatCurrency(user?.wallet_balance || 0)}</p>
            </div>
            <div className="card">
              <p className="stat-label mb-1">Portfolio Value</p>
              <p className="stat-value">{formatCurrency(portfolio?.portfolio_value || 0)}</p>
            </div>
            <div className="card">
              <p className="stat-label mb-1">Total P&L</p>
              <p className={`stat-value ${getPnlClass(portfolio?.total_pnl)}`}>
                {portfolio ? formatCurrency(portfolio.total_pnl) : '—'}
              </p>
            </div>
            <div className="card">
              <p className="stat-label mb-1">Risk Score</p>
              <div className="flex items-center gap-2">
                <p className="stat-value">{portfolio?.risk_score || 0}</p>
                <span className="text-xs text-text-muted font-body">{portfolio?.risk_label || 'No Holdings'}</span>
              </div>
            </div>
          </div>

          {/* Main Grid */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column: Stocks + News */}
            <div className="lg:col-span-2 space-y-5">
              {/* Tabs */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveTab('stocks')}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-display font-semibold transition-all ${
                    activeTab === 'stocks' ? 'bg-accent-green text-bg-primary' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  <BarChart2 size={14} /> Markets
                </button>
                <button
                  onClick={() => setActiveTab('news')}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-display font-semibold transition-all ${
                    activeTab === 'news' ? 'bg-accent-green text-bg-primary' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  <Newspaper size={14} /> News <span className="font-mono text-xs">({news.length})</span>
                </button>
                <div className="ml-auto flex items-center gap-2">
                  {activeTab === 'stocks' && (
                    <div className="relative">
                      <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search stocks..."
                        className="bg-bg-secondary border border-border rounded-lg pl-8 pr-3 py-1.5 text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-accent-green w-44"
                      />
                    </div>
                  )}
                  <button
                    onClick={activeTab === 'stocks' ? loadStocks : loadNews}
                    className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-bg-hover transition-all"
                  >
                    <RefreshCw size={13} />
                  </button>
                </div>
              </div>

              {/* Stocks Table */}
              {activeTab === 'stocks' && (
                <div className="card p-0 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left text-xs text-text-muted uppercase tracking-wider px-4 py-3 font-body">Symbol</th>
                          <th className="text-right text-xs text-text-muted uppercase tracking-wider px-4 py-3 font-body">Price</th>
                          <th className="text-right text-xs text-text-muted uppercase tracking-wider px-4 py-3 font-body hidden sm:table-cell">Change</th>
                          <th className="text-right text-xs text-text-muted uppercase tracking-wider px-4 py-3 font-body hidden md:table-cell">Owned</th>
                          <th className="text-right text-xs text-text-muted uppercase tracking-wider px-4 py-3 font-body">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {loadingStocks ? (
                          Array(8).fill(0).map((_, i) => (
                            <tr key={i} className="border-b border-border/50">
                              <td colSpan={5} className="px-4 py-3">
                                <div className="h-6 bg-bg-secondary rounded animate-pulse" />
                              </td>
                            </tr>
                          ))
                        ) : filteredStocks.map(stock => {
                          const holding = getHolding(stock.symbol)
                          return (
                            <tr
                              key={stock.symbol}
                              className="border-b border-border/50 hover:bg-bg-hover transition-colors group cursor-pointer"
                              onClick={() => setSelectedStock(stock)}
                            >
                              <td className="px-4 py-3">
                                <div>
                                  <p className="font-mono text-sm font-semibold text-text-primary group-hover:text-accent-green transition-colors">{stock.symbol}</p>
                                  <p className="text-xs text-text-muted font-body truncate max-w-[120px]">{stock.company_name}</p>
                                </div>
                              </td>
                              <td className="px-4 py-3 text-right">
                                <p className="font-mono text-sm font-semibold text-text-primary">{formatCurrency(stock.price)}</p>
                              </td>
                              <td className="px-4 py-3 text-right hidden sm:table-cell">
                                <div className={`inline-flex items-center gap-1 text-xs font-mono ${isPositive(stock.change) ? 'text-accent-green' : 'text-accent-red'}`}>
                                  {isPositive(stock.change) ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                                  {formatPercent(stock.change_percent)}
                                </div>
                              </td>
                              <td className="px-4 py-3 text-right hidden md:table-cell">
                                {holding ? (
                                  <div>
                                    <p className="text-xs font-mono text-text-primary">{holding.quantity} shares</p>
                                    <p className={`text-xs font-mono ${getPnlClass(holding.unrealized_pnl)}`}>
                                      {formatCurrency(holding.unrealized_pnl)}
                                    </p>
                                  </div>
                                ) : <span className="text-text-muted text-xs">—</span>}
                              </td>
                              <td className="px-4 py-3 text-right">
                                <button
                                  onClick={(e) => { e.stopPropagation(); setSelectedStock(stock) }}
                                  className="text-xs px-3 py-1.5 bg-bg-secondary border border-border rounded-lg hover:border-accent-green hover:text-accent-green transition-all font-body group-hover:border-accent-green/50"
                                >
                                  Trade
                                </button>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* News Feed */}
              {activeTab === 'news' && (
                <div className="space-y-3">
                  {loadingNews ? (
                    Array(4).fill(0).map((_, i) => (
                      <div key={i} className="card">
                        <div className="h-4 bg-bg-secondary rounded animate-pulse mb-2" />
                        <div className="h-3 bg-bg-secondary rounded animate-pulse w-3/4" />
                      </div>
                    ))
                  ) : news.map((article, i) => (
                    <div key={i} className="card-hover group">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <a
                            href={article.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-body font-medium text-text-primary text-sm hover:text-accent-green transition-colors line-clamp-2 flex items-start gap-1"
                          >
                            {article.title}
                            <ArrowUpRight size={11} className="flex-shrink-0 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </a>
                          <p className="text-text-muted text-xs font-body mt-1.5 line-clamp-2">{article.summary}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-xs text-text-muted font-body">{article.source}</span>
                            <span className="text-text-muted text-xs">•</span>
                            <span className="text-xs text-text-muted font-mono">{timeAgo(article.published_at || article.fetched_at)}</span>
                          </div>
                        </div>
                        <span className={`flex-shrink-0 ${getSentimentBadge(article.sentiment)}`}>
                          {article.sentiment}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right Column: Movers + Quick Stats */}
            <div className="space-y-4">
              {/* Top Gainers */}
              <div className="card">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={14} className="text-accent-green" />
                  <h3 className="font-display font-semibold text-sm text-text-primary">Top Gainers</h3>
                </div>
                <div className="space-y-2">
                  {gainers.map(s => (
                    <button
                      key={s.symbol}
                      onClick={() => setSelectedStock(s)}
                      className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-bg-hover transition-colors"
                    >
                      <div className="text-left">
                        <p className="font-mono text-xs font-semibold text-text-primary">{s.symbol}</p>
                        <p className="text-xs text-text-muted font-body">{formatCurrency(s.price)}</p>
                      </div>
                      <span className="font-mono text-xs text-accent-green font-semibold">
                        {formatPercent(s.change_percent)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Top Losers */}
              <div className="card">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingDown size={14} className="text-accent-red" />
                  <h3 className="font-display font-semibold text-sm text-text-primary">Top Losers</h3>
                </div>
                <div className="space-y-2">
                  {losers.map(s => (
                    <button
                      key={s.symbol}
                      onClick={() => setSelectedStock(s)}
                      className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-bg-hover transition-colors"
                    >
                      <div className="text-left">
                        <p className="font-mono text-xs font-semibold text-text-primary">{s.symbol}</p>
                        <p className="text-xs text-text-muted font-body">{formatCurrency(s.price)}</p>
                      </div>
                      <span className="font-mono text-xs text-accent-red font-semibold">
                        {formatPercent(s.change_percent)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Feed Indicator */}
              <div className={`card flex items-center gap-2 ${connected ? 'border-accent-green/20' : ''}`}>
                <div className={`w-2 h-2 rounded-full ${connected ? 'bg-accent-green animate-pulse' : 'bg-text-muted'}`} />
                <div>
                  <p className="text-xs font-mono text-text-primary">{connected ? 'Live Feed Active' : 'Connecting...'}</p>
                  <p className="text-xs text-text-muted font-body">Prices update every 3s</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trade Modal */}
        {selectedStock && (
          <TradeModal
            stock={selectedStock}
            holding={getHolding(selectedStock.symbol)}
            walletBalance={user?.wallet_balance || 0}
            onClose={() => setSelectedStock(null)}
            onSuccess={handleTradeSuccess}
          />
        )}
      </Layout>
    </>
  )
}
