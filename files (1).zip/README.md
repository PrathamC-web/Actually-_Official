# Actually — Real-Time Stock Market Simulation

> Trade with virtual ₹1,00,000. React to live financial news. Beat the market.

## 🏗 Architecture

```
Client (React + Vite + Tailwind)
    ↕ REST API + WebSocket
Backend (FastAPI + Python)
    ├── Auth Service (JWT)
    ├── Trading Engine (Buy/Sell/P&L)
    ├── Market Data (Alpha Vantage / Simulation)
    ├── News AI (OpenAI / Heuristic)
    └── Leaderboard
    ↕
PostgreSQL Database
```

---

## 📁 Project Structure

```
actually/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── auth.py          # Register, Login, /me
│   │   │       ├── trading.py       # Trade, Portfolio, Transactions
│   │   │       ├── market.py        # Stock quotes
│   │   │       ├── news.py          # AI news feed
│   │   │       ├── leaderboard.py   # Rankings
│   │   │       └── websocket.py     # WS endpoints
│   │   ├── core/
│   │   │   ├── config.py            # Settings from env
│   │   │   └── security.py          # JWT, password hashing
│   │   ├── db/
│   │   │   └── database.py          # SQLAlchemy engine + session
│   │   ├── models/
│   │   │   ├── user.py
│   │   │   ├── portfolio.py
│   │   │   ├── transaction.py
│   │   │   └── news.py
│   │   ├── schemas/
│   │   │   ├── auth.py
│   │   │   └── trading.py
│   │   ├── services/
│   │   │   ├── user_service.py
│   │   │   ├── stock_service.py     # Alpha Vantage + simulation
│   │   │   ├── news_service.py      # AI summarization
│   │   │   └── trading_service.py   # Core trading engine
│   │   ├── websockets/
│   │   │   └── manager.py           # WS connection manager
│   │   └── main.py                  # FastAPI app entry
│   ├── requirements.txt
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── api/index.js              # Axios client + all API calls
    │   ├── components/
    │   │   ├── layout/
    │   │   │   ├── Layout.jsx
    │   │   │   └── Navbar.jsx
    │   │   └── ui/
    │   │       ├── ProtectedRoute.jsx
    │   │       ├── TickerTape.jsx
    │   │       └── TradeModal.jsx
    │   ├── context/AuthContext.jsx   # Global auth state
    │   ├── hooks/useWebSocket.js     # Market + Portfolio WS hooks
    │   ├── pages/
    │   │   ├── LoginPage.jsx
    │   │   ├── RegisterPage.jsx
    │   │   ├── DashboardPage.jsx     # Market + News
    │   │   ├── PortfolioPage.jsx     # Holdings + History + Charts
    │   │   └── LeaderboardPage.jsx
    │   ├── utils/format.js           # Currency, % formatters
    │   ├── App.jsx                   # Router
    │   └── main.jsx
    ├── tailwind.config.js
    ├── vite.config.js
    └── package.json
```

---

## 🚀 Local Setup Guide

### Prerequisites
- Python 3.11+
- Node.js 18+
- PostgreSQL 14+

---

### Step 1: Clone and navigate

```bash
git clone <your-repo>
cd actually
```

---

### Step 2: Set up PostgreSQL

```sql
-- In psql:
CREATE DATABASE actually_db;
CREATE USER actually_user WITH PASSWORD 'yourpassword';
GRANT ALL PRIVILEGES ON DATABASE actually_db TO actually_user;
```

---

### Step 3: Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your values (see below)

# Start server (tables auto-created on first run)
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Backend .env file:**
```env
DATABASE_URL=postgresql+asyncpg://actually_user:yourpassword@localhost:5432/actually_db
SYNC_DATABASE_URL=postgresql://actually_user:yourpassword@localhost:5432/actually_db
SECRET_KEY=your-super-secret-key-at-least-32-characters-long
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=1440

# Optional: Real stock data (free tier at alphavantage.co)
ALPHA_VANTAGE_API_KEY=your_key_here

# Optional: Real news (free tier at newsapi.org)
NEWS_API_KEY=your_key_here

# Optional: AI summarization
OPENAI_API_KEY=your_key_here

STARTING_BALANCE=100000.0
CORS_ORIGINS=http://localhost:5173
```

> Without API keys, the app uses realistic simulated data. It works perfectly for demo.

---

### Step 4: Frontend Setup

```bash
cd frontend

npm install

cp .env.example .env
# .env contents:
# VITE_API_BASE_URL=http://localhost:8000
# VITE_WS_BASE_URL=ws://localhost:8000

npm run dev
```

App runs at: **http://localhost:5173**
API docs at: **http://localhost:8000/docs**

---

## 🗄 Database Schema

### users
| Column | Type | Notes |
|--------|------|-------|
| id | SERIAL PK | |
| username | VARCHAR(50) UNIQUE | |
| email | VARCHAR(100) UNIQUE | |
| hashed_password | VARCHAR(255) | bcrypt |
| full_name | VARCHAR(100) | nullable |
| wallet_balance | FLOAT | default 100000 |
| starting_balance | FLOAT | for P&L calc |
| is_active | BOOLEAN | |
| created_at | TIMESTAMPTZ | |

### portfolio_items
| Column | Type | Notes |
|--------|------|-------|
| id | SERIAL PK | |
| user_id | FK → users | CASCADE DELETE |
| symbol | VARCHAR(20) | indexed |
| company_name | VARCHAR(100) | |
| quantity | FLOAT | |
| average_price | FLOAT | weighted avg |
| sector | VARCHAR(50) | |
| updated_at | TIMESTAMPTZ | auto-update |

### transactions
| Column | Type | Notes |
|--------|------|-------|
| id | SERIAL PK | |
| user_id | FK → users | |
| symbol | VARCHAR(20) | |
| trade_type | ENUM(BUY,SELL) | |
| quantity | FLOAT | |
| price | FLOAT | executed price |
| total_value | FLOAT | qty * price |
| wallet_balance_after | FLOAT | snapshot |
| realized_pnl | FLOAT | SELL only |
| avg_price_at_trade | FLOAT | for records |
| created_at | TIMESTAMPTZ | indexed |

### news_articles
| Column | Type | Notes |
|--------|------|-------|
| id | SERIAL PK | |
| title | VARCHAR(500) | |
| url | VARCHAR(1000) | |
| source | VARCHAR(100) | |
| summary | TEXT | AI generated |
| sentiment | ENUM | Bullish/Bearish/Neutral |
| related_symbols | VARCHAR(200) | comma-separated |
| published_at | TIMESTAMPTZ | |
| fetched_at | TIMESTAMPTZ | indexed |

---

## 🔌 API Reference

### Auth
```
POST /api/auth/register   → { access_token, user }
POST /api/auth/login      → { access_token, user }
GET  /api/auth/me         → UserOut
```

### Market
```
GET  /api/market/stocks           → StockQuote[]
GET  /api/market/stocks/{symbol}  → StockQuote
GET  /api/market/symbols          → { symbols: string[] }
```

### Trading
```
POST /api/trading/trade           → TradeResponse
GET  /api/trading/portfolio       → PortfolioSummary
GET  /api/trading/transactions    → TransactionOut[]
```

### News
```
GET  /api/news/  → NewsArticle[]  (cached 5min)
```

### Leaderboard
```
GET  /api/leaderboard/  → LeaderboardEntry[]
```

### WebSockets
```
WS  /ws/market           → price_update every 3s (no auth)
WS  /ws/portfolio?token= → portfolio_update on trade (auth required)
```

---

## 💡 Trading Engine Details

### Buy Logic
1. Fetch live price from Alpha Vantage (or simulation)
2. Validate: `wallet_balance >= quantity * price`
3. Deduct from wallet
4. If existing holding: recalculate weighted average price
   - `new_avg = (old_qty * old_avg + new_qty * new_price) / total_qty`
5. Create/update PortfolioItem
6. Record Transaction

### Sell Logic
1. Validate: `owned_quantity >= requested_quantity`
2. Calculate realized P&L: `(current_price - avg_price) * quantity`
3. Credit wallet: `wallet += quantity * price`
4. Reduce holding quantity (delete if zero)
5. Record Transaction with realized_pnl

### P&L Calculations
- **Unrealized P&L**: `(current_price - avg_price) * quantity`
- **Realized P&L**: Captured at sell time
- **Total P&L**: `total_value - starting_balance`
- **Daily Change**: `portfolio_value - total_invested`

### Risk Score (0-100)
- **Concentration (50pts)**: HHI of portfolio weights
- **Sector (30pts)**: HHI of sector weights  
- **Diversity (20pts)**: Based on number of holdings
- Labels: Low Risk / Low-Medium / Medium Risk / High Risk

---

## 🤖 AI News Integration

The `ai_summarize_news()` function in `news_service.py`:

1. **With OpenAI key**: Calls GPT-3.5-turbo, returns structured JSON
2. **Without key**: Uses keyword heuristics for sentiment detection
3. **Response format**: `{ summary: str, sentiment: "Bullish" | "Bearish" | "Neutral" }`

To swap to Anthropic Claude API:
```python
# In news_service.py, replace the OpenAI call with:
response = await client.post(
    "https://api.anthropic.com/v1/messages",
    headers={"x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01"},
    json={"model": "claude-3-haiku-20240307", "max_tokens": 150, "messages": [...]}
)
```

---

## ☁️ Deployment

### Backend on Render

1. Create a new **Web Service** on render.com
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Add environment variables from `.env.example`
5. Add a PostgreSQL database from Render (free tier available)
6. Set `DATABASE_URL` to the Render Postgres URL

### Frontend on Vercel

```bash
cd frontend
npm run build

# Install Vercel CLI
npm i -g vercel
vercel deploy --prod
```

Set environment variable in Vercel dashboard:
- `VITE_API_BASE_URL` = your Render backend URL
- `VITE_WS_BASE_URL` = `wss://your-backend.onrender.com`

### Docker Compose (self-hosted)

```yaml
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: actually_db
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql+asyncpg://postgres:password@db:5432/actually_db
      SECRET_KEY: your-secret-key-here
    depends_on:
      - db

  frontend:
    build: ./frontend
    ports:
      - "5173:80"
    environment:
      VITE_API_BASE_URL: http://localhost:8000

volumes:
  pgdata:
```

---

## 🔐 Security

- Passwords hashed with **bcrypt** via passlib
- JWT tokens with configurable expiry (default 24h)
- All trading routes require `Authorization: Bearer <token>`
- WebSocket auth via query param token
- SQL injection protected by SQLAlchemy ORM
- CORS configured to allowed origins only

---

## 🧪 Testing the API

Once running, visit **http://localhost:8000/docs** for the interactive Swagger UI.

Quick test flow:
1. `POST /api/auth/register` → get token
2. `GET /api/market/stocks` → see live prices
3. `POST /api/trading/trade` → buy RELIANCE (use token)
4. `GET /api/trading/portfolio` → check P&L
5. `GET /api/leaderboard/` → see rankings
